const { Enquiry, Admission } = require('../models');
const { ROLES, PAGINATION, ENQUIRY_STATUSES, STATUS_FLOW } = require('../config/constants');
const { canModifyEnquiry } = require('../utils/accessControl');
const AppError = require('../utils/AppError');

class EnquiryService {
  async createEnquiry(data, user) {
    const isAdmin = user.role === ROLES.ADMIN;

    const enquiry = await Enquiry.create({
      ...data,
      createdBy: user.id,
      assignedTo: isAdmin ? null : user.id,
      notes: [],
      timeline: [{
        type: 'created',
        message: `Enquiry created by ${user.name}`,
        user: user.id,
        userName: user.name,
        timestamp: new Date()
      }]
    });

    return await this.getEnquiryById(enquiry._id);
  }

  async getEnquiryById(id) {
    const enquiry = await Enquiry.findById(id)
      .populate('assignedTo', 'name email')
      .populate('createdBy', 'name email');

    if (!enquiry) throw new AppError('Enquiry not found', 404);
    return enquiry;
  }

  async listEnquiries(query, user) {
    const page = parseInt(query.page) || PAGINATION.DEFAULT_PAGE;
    const limit = Math.min(parseInt(query.limit) || PAGINATION.DEFAULT_LIMIT, PAGINATION.MAX_LIMIT);
    const skip = (page - 1) * limit;

    const filter = this._buildFilter(query, user);

    const [enquiries, totalCount, admissionIds] = await Promise.all([
      Enquiry.find(filter)
        .populate('assignedTo', 'name email')
        .populate('createdBy', 'name email')
        .sort({ createdAt: -1 })
        .skip(skip)
        .limit(limit)
        .lean(),
      Enquiry.countDocuments(filter),
      Admission.distinct('enquiryId')
    ]);

    const admissionSet = new Set(admissionIds.map(id => id.toString()));

    return {
      enquiries: enquiries.map(e => ({
        ...e,
        isUnassigned: !e.assignedTo,
        hasAdmission: admissionSet.has(e._id.toString())
      })),
      pagination: {
        page,
        limit,
        totalCount,
        totalPages: Math.ceil(totalCount / limit),
        hasNextPage: page < Math.ceil(totalCount / limit),
        hasPrevPage: page > 1
      }
    };
  }

  // List ALL enquiries (no access restriction for read-only)
  async listAllEnquiries(query, user) {
    const page = parseInt(query.page) || PAGINATION.DEFAULT_PAGE;
    const limit = Math.min(parseInt(query.limit) || PAGINATION.DEFAULT_LIMIT, PAGINATION.MAX_LIMIT);
    const skip = (page - 1) * limit;

    const filter = {};
    if (query.status) filter.status = query.status;
    if (query.search) {
      filter.$or = [
        { name: { $regex: query.search, $options: 'i' } },
        { mobile: { $regex: query.search, $options: 'i' } },
        { email: { $regex: query.search, $options: 'i' } }
      ];
    }

    const [enquiries, totalCount, admissionIds] = await Promise.all([
      Enquiry.find(filter)
        .populate('assignedTo', 'name email')
        .populate('createdBy', 'name email')
        .sort({ createdAt: -1 })
        .skip(skip)
        .limit(limit)
        .lean(),
      Enquiry.countDocuments(filter),
      Admission.distinct('enquiryId')
    ]);

    const admissionSet = new Set(admissionIds.map(id => id.toString()));

    return {
      enquiries: enquiries.map(e => ({
        ...e,
        isUnassigned: !e.assignedTo,
        hasAdmission: admissionSet.has(e._id.toString())
      })),
      pagination: {
        page,
        limit,
        totalCount,
        totalPages: Math.ceil(totalCount / limit),
        hasNextPage: page < Math.ceil(totalCount / limit),
        hasPrevPage: page > 1
      }
    };
  }

  // Single update API - handles status + note + followUpDate
  async updateEnquiry(enquiryId, data, user) {
    const { status, note, followUpDate } = data;

    const enquiry = await Enquiry.findById(enquiryId);
    if (!enquiry) throw new AppError('Enquiry not found', 404);

    // Access control
    if (!canModifyEnquiry(user, enquiry)) {
      throw new AppError('Access denied. You can only modify enquiries assigned to you.', 403);
    }

    // Check if converted (locked for non-admins)
    if (enquiry.status === ENQUIRY_STATUSES.CONVERTED && user.role !== ROLES.ADMIN) {
      throw new AppError('Converted enquiries can only be modified by admin', 403);
    }

    // Validation rules
    if (status && !note) {
      throw new AppError('Note is required when updating status', 400);
    }

    if (status === ENQUIRY_STATUSES.FOLLOW_UP && !followUpDate) {
      throw new AppError('Follow-up date is required when status is FOLLOW_UP', 400);
    }

    // Status flow validation
    if (status && status !== enquiry.status) {
      const allowedTransitions = STATUS_FLOW[enquiry.status] || [];
      if (!allowedTransitions.includes(status)) {
        throw new AppError(
          `Invalid status transition from "${enquiry.status}" to "${status}". ` +
          `Allowed: ${allowedTransitions.join(', ') || 'none'}`,
          400
        );
      }
    }

    // Auto-assign on first counselor action
    let autoAssigned = false;
    if (!enquiry.assignedTo && user.role === ROLES.COUNSELOR) {
      enquiry.assignedTo = user.id;
      autoAssigned = true;
    }

    const previousStatus = enquiry.status;
    let requiresPaymentSetup = false;

    // Update status
    if (status && status !== enquiry.status) {
      enquiry.status = status;
      enquiry.timeline.push({
        type: 'status_change',
        message: `Status changed from "${previousStatus}" to "${status}"`,
        user: user.id,
        userName: user.name,
        timestamp: new Date(),
        metadata: { previousStatus, newStatus: status }
      });

      if (status === ENQUIRY_STATUSES.CONVERTED) {
        requiresPaymentSetup = true;
      }
    }

    // Add note
    if (note) {
      enquiry.notes.push({
        text: note,
        addedBy: user.id,
        createdAt: new Date()
      });
      enquiry.timeline.push({
        type: 'note',
        message: `Note added by ${user.name}`,
        user: user.id,
        userName: user.name,
        timestamp: new Date()
      });
    }

    // Update followUpDate
    if (followUpDate !== undefined) {
      enquiry.followUpDate = followUpDate || null;
    }

    enquiry.updatedAt = new Date();
    await enquiry.save();

    return {
      enquiry: await this.getEnquiryById(enquiryId),
      autoAssigned,
      requiresPaymentSetup
    };
  }

  async bulkUpload(dataArray, user) {
    const created = [];
    const errors = [];

    for (let i = 0; i < dataArray.length; i++) {
      try {
        const data = dataArray[i];

        if (!data.name || !data.mobile || !data.courseInterested) {
          errors.push({ row: i + 1, error: 'Missing required fields (name, mobile, courseInterested)' });
          continue;
        }

        const mobile = String(data.mobile).replace(/\D/g, '');
        if (mobile.length !== 10) {
          errors.push({ row: i + 1, error: 'Invalid mobile number (must be 10 digits)' });
          continue;
        }

        const enquiry = await Enquiry.create({
          name: data.name,
          mobile,
          email: data.email || null,
          courseInterested: data.courseInterested,
          status: data.status || ENQUIRY_STATUSES.NEW,
          assignedTo: null,
          createdBy: user.id,
          notes: [],
          timeline: [{
            type: 'created',
            message: `Enquiry created via bulk upload by ${user.name}`,
            user: user.id,
            userName: user.name,
            timestamp: new Date()
          }]
        });

        created.push(enquiry);
      } catch (err) {
        errors.push({ row: i + 1, error: err.message });
      }
    }

    return { created: created.length, errors, enquiries: created };
  }

  async deleteEnquiry(id, user) {
    const enquiry = await Enquiry.findById(id);
    if (!enquiry) throw new AppError('Enquiry not found', 404);

    if (enquiry.status === ENQUIRY_STATUSES.CONVERTED && user.role !== ROLES.ADMIN) {
      throw new AppError('Converted enquiries can only be deleted by admin', 403);
    }

    await Enquiry.findByIdAndDelete(id);
    return { message: 'Enquiry deleted successfully' };
  }

  // Build filter with proper access control
  _buildFilter(query, user) {
    const filter = {};

    // Access control: counselors can only see assigned + unassigned
    if (user.role === ROLES.COUNSELOR) {
      filter.$and = filter.$and || [];
      filter.$and.push({
        $or: [
          { assignedTo: null },
          { assignedTo: user.id }
        ]
      });
    }

    if (query.status) filter.status = query.status;

    if (query.search) {
      const searchFilter = {
        $or: [
          { name: { $regex: query.search, $options: 'i' } },
          { mobile: { $regex: query.search, $options: 'i' } },
          { email: { $regex: query.search, $options: 'i' } }
        ]
      };
      filter.$and = filter.$and || [];
      filter.$and.push(searchFilter);
    }

    if (query.assignedTo === 'null') filter.assignedTo = null;
    if (query.assignedTo === 'me' && user.role === ROLES.COUNSELOR) filter.assignedTo = user.id;

    // Follow-up filters
    const today = new Date();
    today.setHours(0, 0, 0, 0);

    if (query.followUpToday === 'true' || query.followUpToday === true) {
      const tomorrow = new Date(today);
      tomorrow.setDate(tomorrow.getDate() + 1);
      filter.followUpDate = { $gte: today, $lt: tomorrow };
    } else if (query.followUpOverdue === 'true' || query.followUpOverdue === true) {
      filter.followUpDate = { $lt: today };
      filter.status = { $ne: ENQUIRY_STATUSES.CONVERTED };
    } else if (query.view === 'default') {
      filter.followUpDate = { $lte: today };
      filter.status = { $ne: ENQUIRY_STATUSES.CONVERTED };
    }

    return filter;
  }
}

module.exports = new EnquiryService();
